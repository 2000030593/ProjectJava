package com.redhat.training;

import java.math.BigDecimal;
import java.util.Date;

public class College {
	public final String objective="abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz";
	@SuppressWarnings("deprecation")
	public final Date myDate = new Date(2022, 12, 06);
	public final String msg = "only past data is allowed";
	public final BigDecimal B = new BigDecimal(123.45);
	public final String ratio = "123:4";
}
