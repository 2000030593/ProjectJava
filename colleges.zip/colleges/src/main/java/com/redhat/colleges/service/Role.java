package com.redhat.colleges.service;

public class Role {
	public static final String deanAcademics_role="deanacademics";
	public static final String hod_role = "hod";
	public static final String courseCoordinator_role = "coursecoordinator";
}
